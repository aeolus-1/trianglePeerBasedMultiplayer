# untitled triangle game

idk what to call it

put it on github so friends can see it

basic platforming game similar to getting over it  
pretty cool to work on  
dont read the code it's to complecated for anyone in the world to understand


demo here - https://aeolus-1.github.io/triangleGame.github.io/

s,d,ArrowLeft,ArrowRight = Move Left/Right  
w, Space, ArrowUp = Jump  
s, ArrowDown = Duck  

Music by nokia


Game map  


![yay](gameMap.png "ur gay now").


