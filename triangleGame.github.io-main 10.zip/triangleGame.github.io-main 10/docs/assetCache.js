var imgCache = {

}
imgCache.musicOn = document.createElement("img")
imgCache.musicOn.src = "assets/imgs/musicOn.png"

imgCache.musicOff = document.createElement("img")
imgCache.musicOff.src = "assets/imgs/musicOff.png"

imgCache.soundOff = document.createElement("img")
imgCache.soundOff.src = "assets/imgs/soundOff.png"

imgCache.soundOn = document.createElement("img")
imgCache.soundOn.src = "assets/imgs/soundOn.png"

imgCache.userPlus = document.createElement("img")
imgCache.userPlus.src = "assets/imgs/userPlus.png"

imgCache.userSub = document.createElement("img")
imgCache.userSub.src = "assets/imgs/userSub.png"

imgCache.resetIcon = document.createElement("img")
imgCache.resetIcon.src = "assets/imgs/resetIcon.png"